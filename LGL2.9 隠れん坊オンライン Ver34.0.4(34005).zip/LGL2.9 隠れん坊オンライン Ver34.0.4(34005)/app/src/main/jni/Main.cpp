#include <list>
#include <vector>
#include <string.h>
#include <pthread.h>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <dlfcn.h>
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "unity/Unity.h"
#include "KittyMemory/MemoryPatch.h"
#include "Menu.h"
#include "RMOD.h"

//Target lib here
#define targetLibName OBFUSCATE("libil2cpp.so")

#include "Includes/Macros.h"

// fancy struct for patches for kittyMemory
struct My_Patches {
    MemoryPatch 
	鬼無敵, 
	マップ判定解除, 
	マップ上限開放,
	無限ジャンプ, 
	スピード, 
	パンチスピード, 
	パンチ距離,
	コロバグ1, 
	隠れ爆弾, 
	オブジェクト削除, 
	壁貫通, 
	スポーン地点, 
	ウォールハック検知回避,
	ユーザーリスト増殖,
	広告削除, 
	巨大化, 
	鬼隠れ増殖, 
	増殖検知回避, 
	チャンネル変更待ち時間なし, 
	チーム判定, 
	鬼スキン強化, 
	スキン選択ノーマル, 
	スキン選択ピエロ, 
	スキン選択シンデレラ, 
	スキン選択骨マフ, 
	スキン選択ヴァンパイア, 
	スキン選択サンタ, 
	スキン選択えなこ, 
	スキン選択魔女, 
	スキン選択うさぎ, 
	スキン選択悪魔, 
	スキン選択フランケン, 
	しっぽ強化最大, 
	覚える時間にパンチ操作可,
	隠れ無敵, 　　
	死体操作,
	無限もの変更,　
	無限もの変更2, 
	無限もの変更3, 
	無限もの変更4, 
	無限もの変更5,
	無限もの変更6,
	無限もの変更7,
	無限もの変更8,
	無限もの変更9,
	無限もの変更10,
	無限もの変更11,
	無限爆弾,
	無限爆弾2, 
	無限爆弾3,
	無限爆弾4, 
	無限爆弾5,
	無限爆弾6,
	無限爆弾7, 
	無限爆弾8, 
	無限復活, 
	無限復活2,
	無限復活3,
	テスト;
    // etc...
} hexPatches;


bool feature1 = false;
bool feature2 = false; 
bool gameready = false;
bool ChatSpam = false;
bool StampAuto = false; 
bool AutoGamev1, AutoGamev10, AutoGamev20, AutoBombv1, AutoBombv10, AutoBombv20, AutoJoinv1, AutoJoinv10;
bool test1, test2;

int levelhack = 0;
int goldhack = 0;
int hidervalue = 0;
int AutoHidervalue = 1;
int AutoBombvalue = 1;  
int Stamptype = 1; 

float isLocalPlayerSize;

void *instanceBtn;

auto AutoGame = reinterpret_cast<void(*) (void *)>(getAbsoluteAddress("libil2cpp.so", 0x1AA17CC));

auto AutoBomb = reinterpret_cast<void(*) (void *)>(getAbsoluteAddress("libil2cpp.so", 0x1AA6C8C));

auto AutoJoin = reinterpret_cast<void(*) (void *)>(getAbsoluteAddress("libil2cpp.so", 0xDD1904));　

// Transform 
void *(*get_transform)(void *component);
void (*Transform_set_localScale)(void *transform, Vector3);

void SetPlayerSize(void *transform, Vector3 scale) {
return Transform_set_localScale(get_transform(transform), scale);
}
// Function pointer splitted because we want to avoid crash when the il2cpp lib isn't loaded.

void (*SendChatMessage)(void* _this, monoString* message, bool text, monoString*);

// Hooking examples. Assuming you know how to write hook

int (*old_Level)(void *instance);
int Level(void *instance) {
    if (instance != NULL && levelhack) {
        return (int) levelhack;
    }
    return old_Level(instance);
}

int (*old_Gold)(void *instance);
int Gold(void *instance) {
    if (instance != NULL && goldhack) {
        return (int) 999999999;
    }
    return old_Gold(instance);
}

void (*Emotion) (void* _this, int i); 
void (*old_Stamp)(void *instance);
void Stamp(void *instance) {
	if(instance != NULL) {
		if(StampAuto) {	
	if (StampAuto) {
		StampAuto = false;
        switch (Stamptype) {
            case 1:
				StampAuto = true;
                Emotion(instance,1);
                break;
            case 2:
				StampAuto = true;
                Emotion(instance,2);
                break;
			case 3:
				StampAuto = true;
                Emotion(instance,3);
                break;
            case 4:
				StampAuto = true;
                Emotion(instance,4);
                break;
			case 5:
				StampAuto = true;
                Emotion(instance,5);
                break;
            case 6:
				StampAuto = true;
                Emotion(instance,6);
                break;
            case 7:
				StampAuto = true;
                Emotion(instance,7);
                break;
			case 8:
				StampAuto = true;
                Emotion(instance,8);
                break;
            case 9:
				StampAuto = true;
                Emotion(instance,9);
                break;
        }
            }
        }
    }
    old_Stamp(instance);
}

void (*old_GameReady)(void *instance);
void GameReadyv1(float *instance) {
    if (instance != NULL) {
       if (gameready) {
            *(bool *) ((uint64_t) instance + 0x20) = false; 
            }
     }
     return old_GameReady(instance);
}

void (*old_DT1)(void *instance);
void DT1(void *instance) {
    if (instance != NULL && AutoGamev1) {
        AutoGame(instance);
    }
　  if (AutoGamev10) {
		AutoGamev10 = false;
        AutoGame(instance);
	}
	if(AutoGamev20) {
      for (int i = 0; i < AutoHidervalue; ++i) {
        if(instance)
        AutoGamev20 = false;
        AutoGame(instance);
    }
  }
    return old_DT1(instance);
}

void (*old_DT2)(void *instance);
void DT2(void *instance) {
    if (instance != NULL && AutoBombv1) {
        AutoBomb(instance);
    }
	if (instance != NULL && AutoBombv20) {
		for (int i = 0; i < AutoBombvalue; ++i) {
        if(instance)
        AutoBomb(instance);
    }
  } 
  	if (AutoBombv10) {
		AutoBombv10 = false;
        AutoBomb(instance);
	}
    return old_DT2(instance);
}

void (*old_DT3)(void *instance);
void DT3(void *instance) {
    if (instance != NULL && AutoJoinv1) {
        AutoJoin(instance);
    }
	if (AutoJoinv10) {
		AutoJoinv10 = false;
        AutoJoin(instance);
    }
    return old_DT3(instance);
}

void(*old_Chatv1)(void *instance);
void Chatv1(void *instance) {
    if(instance != NULL) {
        if (ChatSpam) {
            SendChatMessage(instance, CreateMonoString("Slice Cast is the best!"), false, CreateMonoString("Slice Cast is the best!"));
        }
    }
    old_Chatv1(instance);
}

int (*old_HiderSel)(void *instance);
int HiderSel(void *instance) {
    if (instance != NULL && hidervalue) {
        return (int) hidervalue;
    }
    return old_HiderSel(instance);
} 


void (*old_Test1)(void *instance, bool value);
void Test1(void *instance, bool value) {
    if (instance != NULL) {
        if (test1) {
            old_Test1(instance, false);
            return;
        }
    }
    old_Test1(instance, value);
}

void (*old_Test2)(void *instance, bool value);
void Test2(void *instance, bool value) {
    if (instance != NULL) {
        if (test2) {
            old_Test2(instance, false);
            return;
        }
    }
    old_Test2(instance, value);
}

void (*old_playersizeUpdate)(void *instance);
void playersizeUpdate(void *instance) {
    if (instance != NULL) {
        if(isLocalPlayerSize){
           SetPlayerSize(instance, Vector3(isLocalPlayerSize, isLocalPlayerSize, isLocalPlayerSize));
        }
    }
    old_playersizeUpdate(instance);
}

//HERE CODE FOR Vector3
// we will run our hacks in a new thread so our while loop doesn't block process main thread
void *hack_thread(void *) {
    LOGI(OBFUSCATE("pthread created"));

    //Check if target lib is loaded
    do {
        sleep(1);
    } while (!isLibraryLoaded(targetLibName));

    //Anti-lib rename
    /*
    do {
        sleep(1);
    } while (!isLibraryLoaded("libYOURNAME.so"));*/

    LOGI(OBFUSCATE("%s has been loaded"), (const char *) targetLibName);

#if defined(__aarch64__) 

    hexPatches.テスト = MemoryPatch::createWithHex(targetLibName,RMOD::テスト1,OBFUSCATE("01 02 A0 E3 1E FF 2F E1"));

    hexPatches.鬼無敵 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1add460")),OBFUSCATE("00 00 80 D2 C0 03 5F D6"));
	
	hexPatches.マップ判定解除 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1a87e20")),OBFUSCATE("C0 03 5F D6"));
	
	hexPatches.マップ上限開放 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x19df868")),OBFUSCATE("C0 03 5F D6"));
	
    hexPatches.無限ジャンプ = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x18cafd4")),OBFUSCATE("1F 20 03 D5"));
	
　　hexPatches.パンチスピード = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1a87c00")),OBFUSCATE("1F 20 03 D5"));	

    hexPatches.パンチ距離 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1c7a174")),OBFUSCATE("00 C0 79 44"));
													
    hexPatches.ウォールハック検知回避 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1a7fab4")),OBFUSCATE("C0 03 5F D6"));	
		
	hexPatches.ユーザーリスト増殖 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0xdd5390")),OBFUSCATE("C0 03 5F D6"));		
													
    hexPatches.鬼隠れ増殖 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1aea868")),OBFUSCATE("00 00 80 D2"));		
																									
    hexPatches.増殖検知回避 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0xdcf17c")),OBFUSCATE("C0 03 5F D6"));																									
	
    hexPatches.チャンネル変更待ち時間なし = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1ac8db8")),OBFUSCATE("C0 03 5F D6"));																							
													
	hexPatches.チーム判定 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1aea638")),OBFUSCATE("F4 03 20 32"));		
													
　　hexPatches.しっぽ強化最大 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1b8b030")),OBFUSCATE("00 00 10 41"));		
													
　　hexPatches.覚える時間にパンチ操作可 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1a87c3c")),OBFUSCATE("E1 03 14 AA"));	
													
	hexPatches.隠れ無敵 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1aed108")),OBFUSCATE("00 00 80 D2"));	
													
    hexPatches.広告削除 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1b47a3c")),OBFUSCATE("E1 03 20 32"));	
													
	hexPatches.巨大化 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1b8ae7c")),OBFUSCATE("00 00 A0 40"));
													
    hexPatches.壁貫通 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x2fb964")),OBFUSCATE("1F 04 00 F1"));		
													
	hexPatches.コロバグ1 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1aeb654")),OBFUSCATE("1F 20 03 D5"));		
													
	hexPatches.隠れ爆弾 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1a7fe54")),OBFUSCATE("1F 20 03 D5"));	
													
	hexPatches.スピード = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1b8ae80")),OBFUSCATE("00 00 F0 42"));		
	
	hexPatches.死体操作 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1a87bd8")),OBFUSCATE("1F 20 03 D5"));	
													
	//スポーン地点固定[異世界]												
    hexPatches.スポーン地点 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1aed0ac")),OBFUSCATE("00 10 2E 1E"));	
													
	hexPatches.オブジェクト削除 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x19d20e4")),OBFUSCATE("E1 03 20 32"));											
													
    //もの変更表示1 											
　　hexPatches.無限もの変更 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1a7bb08")),OBFUSCATE("E1 03 20 32"));			
													
	//もの変更表示2 											
　　hexPatches.無限もの変更2  = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1a7ca40")),OBFUSCATE("E1 03 20 32"));			
													
    //もの変更表示3										
　　hexPatches.無限もの変更3 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1a96cc0")),OBFUSCATE("E1 03 20 32"));		
																									
    //もの変更表示4											
　　hexPatches.無限もの変更4 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1adacec")),OBFUSCATE("E1 03 20 32"));	
													
	//もの変更表示5 											
　　hexPatches.無限もの変更5 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1ad967c")),OBFUSCATE("E1 03 20 32"));	
													
	//もの変更回数1 											
　　hexPatches.無限もの変更6 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1a7b980")),OBFUSCATE("1F 20 03 D5"));		
													
    //もの変更回数2											
　　hexPatches.無限もの変更7 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1a7b9bc")),OBFUSCATE("1F 20 03 D5"));		
													
    //もの変更検知回避 											
　　hexPatches.無限もの変更8 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1aecf34")),OBFUSCATE("1F 20 03 D5"));												
													
　　//145秒過ぎてももの変更操作可能											
　　hexPatches.無限もの変更9 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1c798b4")),OBFUSCATE("1F 20 03 D5"));	
													
    //検知されてももの変更可能　表示										
　　hexPatches.無限もの変更10 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1a7fbc0")),OBFUSCATE("E1 03 20 32"));	

	//検知されてももの変更可能 回数										
　　hexPatches.無限もの変更11 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1a7b990")),OBFUSCATE("E0 03 1F AA"));	
																									
    //無限爆弾鬼表示1											
　　hexPatches.無限爆弾 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x18c65c8")),OBFUSCATE("E1 03 20 32"));		
													
    //無限爆弾鬼表示2											
　　hexPatches.無限爆弾2 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x18c6710")),OBFUSCATE("E1 03 20 32"));												
													
    //無限爆弾鬼表示3											
　　hexPatches.無限爆弾3 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x18c6850")),OBFUSCATE("E1 03 20 32"));	
													
	//無限爆弾隠れ表示4 											
　　hexPatches.無限爆弾4 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x18c6954")),OBFUSCATE("E1 03 20 32"));
													
	//無限爆弾回数表示5											
　　hexPatches.無限爆弾5 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1a8018c")),OBFUSCATE("E1 03 20 32"));	
													
	//無限爆弾回数1										
　　hexPatches.無限爆弾6 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1a7fe68")),OBFUSCATE("00 F0 27 1E"));											
													
	//無限爆弾回数2											
　　hexPatches.無限爆弾7 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1a7fe8c")),OBFUSCATE("00 F0 27 1E"));	
													
	//無限爆弾向き 逆さま							
　　hexPatches.無限爆弾8  = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1a7ffa8")),OBFUSCATE("00 00 80 D2"));																							
													
	//無限復活表示1											
　　hexPatches.無限復活 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1aa0110")),OBFUSCATE("E1 03 20 32"));		
													
	//無限復活表示2											
　　hexPatches.無限復活2 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1aff0d0")),OBFUSCATE("E1 03 20 32"));	
													
   //無限復活表示3											
　　hexPatches.無限復活3 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1b01a74")),OBFUSCATE("E1 03 20 32"));

    A64HookFunction((void*)getAbsoluteAddress(targetLibName, 0x1A2F5C4), (void*)playersizeUpdate, (void**)&old_playersizeUpdate);	

    A64HookFunction((void*)getAbsoluteAddress(targetLibName, 0x1A2F5C4), (void*)Test1, (void**)&old_Test1);	
	
	A64HookFunction((void*)getAbsoluteAddress(targetLibName, 0x1A32A98), (void*)Test2, (void**)&old_Test2);	

    A64HookFunction((void*)getAbsoluteAddress(targetLibName, 0x1a31f14), (void*)HiderSel, (void**)&old_HiderSel);	
 				
	A64HookFunction((void*)getAbsoluteAddress(targetLibName, 0x1A7A768), (void*)Stamp, (void**)&old_Stamp);													
		
    Emotion = (void(*)(void *,int))getAbsoluteAddress("libil2cpp.so", 0x1A7C38C);
	
	A64HookFunction((void*)getAbsoluteAddress(targetLibName, 0x1A7A768), (void*)DT1, (void**)&old_DT1);	
	
	AutoGame = (void (*)(void *)) getAbsoluteAddress("libil2cpp.so", 0x1A7B918);	
	
	A64HookFunction((void*)getAbsoluteAddress(targetLibName, 0x1A87B34), (void*)DT2, (void**)&old_DT2);	
	
	AutoBomb = (void (*)(void *)) getAbsoluteAddress("libil2cpp.so", 0x1a7fdd8);	
	
	A64HookFunction((void*)getAbsoluteAddress(targetLibName, 0x1A7A768), (void*)DT3, (void**)&old_DT3);	
	
	AutoJoin = (void (*)(void *)) getAbsoluteAddress("libil2cpp.so", 0x1A79324);	
													
	A64HookFunction((void*)getAbsoluteAddress(targetLibName, 0x1AD75A4), (void*)GameReadyv1, (void**)&old_GameReady);		
	
    A64HookFunction((void*)getAbsoluteAddress(targetLibName, 0x1a73aa0), (void*)Level, (void**)&old_Level);
	
    A64HookFunction((void*)getAbsoluteAddress(targetLibName, 0x1a72874), (void*)Gold, (void**)&old_Gold);

	A64HookFunction((void*)getAbsoluteAddress(targetLibName, 0x1A7A768), (void*)Chatv1, (void**)&old_Chatv1);
	
	SendChatMessage =(void (*)(void*, monoString*, bool, monoString*))getAbsoluteAddress(targetLibName, 0x1A7351C);
	
	get_transform = (void *(*)(void *))getAbsoluteAddress(targetLibName, 0x1D955EC);
	
　  Transform_set_localScale = (void (*)(void*, Vector3))getAbsoluteAddress(targetLibName, 0x2B4D720);　　　
	
	//String_CreateString = (monoString*(*)(void *,const char *))getAbsoluteAddress(targetLibName, 0x118AD98);
 
    //get_StringInstance  = (void (*))getAbsoluteAddress(targetLibName,0x118AD98);
	
#else

    LOGI(OBFUSCATE("Done"));
#endif
    
    return NULL;
}

//JNI calls
extern "C" {

// Do not change or translate the first text unless you know what you are doing

JNIEXPORT jobjectArray
JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_getFeatureList(JNIEnv *env, jobject context) {
    jobjectArray ret;

    //Toasts added here so it's harder to remove it
    MakeToast(env, context, OBFUSCATE("隠れん坊オンライン チート"), Toast::LENGTH_LONG);

    const char *features[] = {
            OBFUSCATE("Category_ステータス"),	
            OBFUSCATE("0_InputValue_レベル"), 
			OBFUSCATE("1_Toggle_コイン"), 
			OBFUSCATE("23_Toggle_広告削除[不安定]"),
			OBFUSCATE("Category_チャット"),
			OBFUSCATE("29_Toggle_チャットスパム"),
			OBFUSCATE("Category_ プレイヤー"), 
			OBFUSCATE("34_Toggle_スピード x2"),
			OBFUSCATE("2_Toggle_無限ジャンプ"),
			OBFUSCATE("32_Toggle_コロバグ[横]"),
			OBFUSCATE("Category_ショップ"),
			OBFUSCATE("4_SeekBar_鬼スキン強化_0_8"),
			OBFUSCATE("5_Toggle_しっぽ強化"),
			OBFUSCATE("Category_無限"), 
			OBFUSCATE("8_Toggle_無限爆弾"),
			OBFUSCATE("9_Toggle_無限もの変更"),
			OBFUSCATE("10_Toggle_無限復活"),
			OBFUSCATE("Category_増殖・検知回避"),
			OBFUSCATE("11_Toggle_ユーザーリスト増殖"),
			OBFUSCATE("12_Toggle_増殖[反映あり]"),
			OBFUSCATE("21_Toggle_増殖検知回避"),
			OBFUSCATE("22_Toggle_ウォールハック検知回避"),
			OBFUSCATE("41_マップ選択検知回避"),
			OBFUSCATE("Category_マップ"),
			OBFUSCATE("6_Toggle_マップ判定解除"),
			OBFUSCATE("7_Toggle_マップ上限開放"),
			OBFUSCATE("26_Toggle_スポーン地点固定[異世界]"),
			OBFUSCATE("31_Toggle_壁貫通"),
			OBFUSCATE("30_Toggle_ゲーム停止[主導権]"),
			OBFUSCATE("27_Toggle_マップオブジェクト削除[主導権]"),
			OBFUSCATE("Category_鬼チーム"), 
			OBFUSCATE("13_Toggle_鬼無敵"),
			OBFUSCATE("14_Toggle_パンチスピード"),
			OBFUSCATE("15_Toggle_パンチ距離"),
			OBFUSCATE("16_Toggle_覚える時間にパンチ操作可能"),	
			OBFUSCATE("47_Toggle_死んでもパンチ操作可能"),
			OBFUSCATE("Category_判定"),
			OBFUSCATE("17_Toggle_鬼判定"),
			OBFUSCATE("18_Spinner_スキン選択_ノーマル,ピエロ,シンデレラ,骨マフ,ヴァンパイア,サンタ,えなこ,魔女,うさぎ,悪魔,フランケン"),
			OBFUSCATE("33_Toggle_隠れ爆弾"),		
			OBFUSCATE("Category_隠れチーム"),
			OBFUSCATE("19_Toggle_物無敵"),
			OBFUSCATE("20_SeekBar_物厳選_0_84"),
			OBFUSCATE("Category_自動化"),
			OBFUSCATE("35_Toggle_もの変更[自動]"),
			OBFUSCATE("37_Button_もの変更[手動] +1"),
			OBFUSCATE("41_Button_もの変更[手動] +選択"),
			OBFUSCATE("42_SeekBar_≫_1_200"),
			OBFUSCATE("36_Toggle_爆弾[自動]"),
			OBFUSCATE("44_Toggle_爆弾[自動] +選択"),
			OBFUSCATE("45_SeekBar_≫_1_100"),
			OBFUSCATE("38_Button_爆弾[手動] +1"),
			OBFUSCATE("28_Toggle_スタンプ自動 +選択"),
			OBFUSCATE("46_SeekBar_≫_0_8"),
			OBFUSCATE("39_Toggle_ゲーム参加[自動]"),
			OBFUSCATE("40_Button_ゲーム参加[手動]"), 
			OBFUSCATE("Category_テスト"),
			OBFUSCATE("48_Toggle_テスト1"),
			OBFUSCATE("49_Toggle_テスト2"),
			OBFUSCATE("50_SeekBar_プレイヤーサイズ_1_50"), 
    };
    //Now you dont have to manually update the number everytime;
    int Total_Feature = (sizeof features / sizeof features[0]);
    ret = (jobjectArray)
            env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
                                env->NewStringUTF(""));

    for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

    pthread_t ptid;
    pthread_create(&ptid, NULL, antiLeech, NULL);

    return (ret);
}

JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_Preferences_Changes(JNIEnv *env, jclass clazz, jobject obj,
                                        jint featNum, jstring featName, jint value,
                                        jboolean boolean, jstring str) {

    LOGD(OBFUSCATE("Feature name: %d - %s | Value: = %d | Bool: = %d | Text: = %s"), featNum,
         env->GetStringUTFChars(featName, 0), value,
         boolean, str != NULL ? env->GetStringUTFChars(str, 0) : "");

    //BE CAREFUL NOT TO ACCIDENTLY REMOVE break;

    switch (featNum) {
        case 0:
            levelhack = value;
            break;
	    case 1:
			goldhack = boolean;
			break;
	    case 2:
			feature1 = boolean;
            if (feature1) {             
                hexPatches.無限ジャンプ.Modify();  			
            } else {
                hexPatches.無限ジャンプ.Restore();  
            }
            break;
		case 3:
			feature1 = boolean;
            if (feature1) {             
                hexPatches.チャンネル変更待ち時間なし.Modify();              
            } else {
                hexPatches.チャンネル変更待ち時間なし.Restore();              
            }
            break;
		case 4:
            switch (value) {
                case 0:
                    MemoryPatch::createWithHex(targetLibName, string2Offset(OBFUSCATE("0x1c2eedc")), OBFUSCATE("01 00 00 00")).Modify();
                    break;
                case 1:
                    MemoryPatch::createWithHex(targetLibName, string2Offset(OBFUSCATE("0x1c2eedc")), OBFUSCATE("02 00 00 00")).Modify();				 
                    break;
                case 2:
                    MemoryPatch::createWithHex(targetLibName, string2Offset(OBFUSCATE("0x1c2eedc")), OBFUSCATE("03 00 00 00")).Modify();
                    break;
                case 3:
                    MemoryPatch::createWithHex(targetLibName, string2Offset(OBFUSCATE("0x1c2eedc")), OBFUSCATE("04 00 00 00")).Modify();
                    break;
                case 4:
                    MemoryPatch::createWithHex(targetLibName, string2Offset(OBFUSCATE("0x1c2eedc")), OBFUSCATE("05 00 00 00")).Modify();
                    break;
			    case 5 :
                    MemoryPatch::createWithHex(targetLibName, string2Offset(OBFUSCATE("0x1c2eedc")), OBFUSCATE("06 00 00 00")).Modify();				 
                    break;
                case 6:
                    MemoryPatch::createWithHex(targetLibName, string2Offset(OBFUSCATE("0x1c2eedc")), OBFUSCATE("07 00 00 00")).Modify();				 
                    break;
                case 7:
                    MemoryPatch::createWithHex(targetLibName, string2Offset(OBFUSCATE("0x1c2eedc")), OBFUSCATE("08 00 00 00")).Modify();
                    break;
			    case 8:
                    MemoryPatch::createWithHex(targetLibName, string2Offset(OBFUSCATE("0x1c2eedc")), OBFUSCATE("09 00 00 00")).Modify();
                    break;
            }
            break;
		case 5:
			feature1 = boolean;
            if (feature1) {             
                hexPatches.しっぽ強化最大.Modify();              
            } else {
                hexPatches.しっぽ強化最大.Restore();              
            }		
            break;
		case 6:
			feature1 = boolean;
            if (feature1) {             
                hexPatches.マップ判定解除.Modify();              
            } else {
                hexPatches.マップ判定解除.Restore();              
            }
            break;
		case 7:
			feature1 = boolean;
            if (feature1) {             
                hexPatches.マップ上限開放.Modify();              
            } else {
                hexPatches.マップ上限開放.Restore();              
            }
            break;
	　　case 8:
			feature2 = boolean;
            if (feature2) {             
                hexPatches.無限爆弾.Modify();   
				hexPatches.無限爆弾2.Modify(); 
				hexPatches.無限爆弾3.Modify(); 
				hexPatches.無限爆弾4.Modify(); 
				hexPatches.無限爆弾5.Modify(); 
				hexPatches.無限爆弾6.Modify(); 
				hexPatches.無限爆弾7.Modify(); 
				hexPatches.無限爆弾8.Modify(); 
            } else {
                hexPatches.無限爆弾.Restore();    
				hexPatches.無限爆弾2.Restore();  
				hexPatches.無限爆弾3.Restore();  
				hexPatches.無限爆弾4.Restore(); 
				hexPatches.無限爆弾5.Restore();  
				hexPatches.無限爆弾6.Restore();  
				hexPatches.無限爆弾7.Restore();  
				hexPatches.無限爆弾8.Restore();
            }
            break;
		case 9:
			feature2 = boolean;
            if (feature2) {             
                hexPatches.無限もの変更.Modify();     
				hexPatches.無限もの変更2.Modify();  
				hexPatches.無限もの変更3.Modify();    
				hexPatches.無限もの変更4.Modify();    
				hexPatches.無限もの変更5.Modify();    
				hexPatches.無限もの変更6.Modify();   
				hexPatches.無限もの変更7.Modify();    
				hexPatches.無限もの変更8.Modify();  
				hexPatches.無限もの変更9.Modify();    
				hexPatches.無限もの変更10.Modify();  
				hexPatches.無限もの変更11.Modify();  
            } else {
                hexPatches.無限もの変更.Restore();   
				hexPatches.無限もの変更2.Restore(); 
				hexPatches.無限もの変更3.Restore(); 
				hexPatches.無限もの変更4.Restore(); 
				hexPatches.無限もの変更5.Restore(); 
				hexPatches.無限もの変更6.Restore(); 
				hexPatches.無限もの変更7.Restore(); 
				hexPatches.無限もの変更8.Restore(); 
				hexPatches.無限もの変更9.Restore(); 
				hexPatches.無限もの変更10.Restore(); 
				hexPatches.無限もの変更11.Restore(); 
            }
            break;
		case 10:
			feature1 = boolean;
            if (feature1) {             
                hexPatches.無限復活.Modify();   
				hexPatches.無限復活2.Modify(); 
				hexPatches.無限復活3.Modify(); 
            } else {
                hexPatches.無限復活.Restore();        
				hexPatches.無限復活2.Restore();  
				hexPatches.無限復活3.Restore();  
            }
            break;
		case 11:
			feature1 = boolean;
            if (feature1) {             
                hexPatches.ユーザーリスト増殖.Modify();              
            } else {
                hexPatches.ユーザーリスト増殖.Restore();              
            }
            break;
		case 12:
			feature1 = boolean;
            if (feature1) {             
                hexPatches.鬼隠れ増殖.Modify();              
            } else {
                hexPatches.鬼隠れ増殖.Restore();              
            }
            break;
		case 13:
			feature1 = boolean;
            if (feature1) {             
                hexPatches.鬼無敵.Modify();              
            } else {
                hexPatches.鬼無敵.Restore();              
            }
            break;
		case 14:
			feature1 = boolean;
            if (feature1) {             
                hexPatches.パンチスピード.Modify();              
            } else {
                hexPatches.パンチスピード.Restore();              
            }
            break;
		case 15:
			feature1 = boolean;
            if (feature1) {             
                hexPatches.パンチ距離.Modify();              
            } else {
                hexPatches.パンチ距離.Restore();              
            }
            break;
		case 16:
			feature1 = boolean;
            if (feature1) {             
                hexPatches.覚える時間にパンチ操作可.Modify();              
            } else {
                hexPatches.覚える時間にパンチ操作可.Restore();              
            }
            break;
		case 17:
			feature1 = boolean;
            if (feature1) {             
                hexPatches.チーム判定.Modify();              
            } else {
                hexPatches.チーム判定.Restore();              
            }
            break;
		case 18:
            switch (value) {
                case 0:
                    hexPatches.スキン選択ノーマル = MemoryPatch::createWithHex(targetLibName, string2Offset(OBFUSCATE("0x1aea634")),OBFUSCATE("f7 03 03 2a"));
                    hexPatches.スキン選択ノーマル.Modify();
                    break;
                case 1:
                    hexPatches.スキン選択ピエロ = MemoryPatch::createWithHex(targetLibName, string2Offset(OBFUSCATE("0x1aea634")),OBFUSCATE("B7 0C 80 D2"));
                    hexPatches.スキン選択ピエロ.Modify();
                    break;
                case 2:
                    hexPatches.スキン選択シンデレラ = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1aea634")),OBFUSCATE("77 0F 80 D2"));
                    hexPatches.スキン選択シンデレラ.Modify();
                    break;
				case 3:
                    hexPatches.スキン選択骨マフ = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1aea634")),OBFUSCATE("D7 0F 80 D2"));
                    hexPatches.スキン選択骨マフ.Modify();
                    break;
				case 4:
                    hexPatches.スキン選択ヴァンパイア = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1aea634")),OBFUSCATE("37 17 80 D2"));
                    hexPatches.スキン選択ヴァンパイア.Modify();
                    break;
				case 5:
                    hexPatches.スキン選択サンタ = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1aea634")),OBFUSCATE("D7 17 80 D2"));
                    hexPatches.スキン選択サンタ.Modify();
                    break;
				case 6:
                    hexPatches.スキン選択えなこ = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1aea634")),OBFUSCATE("77 22 80 D2"));
                    hexPatches.スキン選択えなこ.Modify();
                    break;
				case 7:
                 　 hexPatches.スキン選択魔女 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1aea634")),OBFUSCATE("17 17 80 D2"));
                    hexPatches.スキン選択魔女.Modify();
                    break;
				case 8:
                 　 hexPatches.スキン選択うさぎ = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1aea634")),OBFUSCATE("D7 16 80 D2"));
                    hexPatches.スキン選択うさぎ.Modify();
                    break;
				case 9:
                 　 hexPatches.スキン選択悪魔 = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1aea634")),OBFUSCATE("F7 16 80 D2"));
                    hexPatches.スキン選択悪魔.Modify();
                    break;		
				case 10:
                 　 hexPatches.スキン選択フランケン = MemoryPatch::createWithHex(targetLibName,string2Offset(OBFUSCATE("0x1aea634")),OBFUSCATE("B7 17 80 D2"));
                    hexPatches.スキン選択フランケン.Modify();
                    break;	
            }
            break;
		case 19:
			feature1 = boolean;
            if (feature1) {             
                hexPatches.隠れ無敵.Modify();              
            } else {
                hexPatches.隠れ無敵.Restore();              
            }
            break;
		case 20:
			hidervalue = value;
			break;
		case 21:
			feature1 = boolean;
            if (feature1) {             
                hexPatches.増殖検知回避.Modify();              
            } else {
                hexPatches.増殖検知回避.Restore();              
            }
            break; 
		case 22:
			feature1 = boolean;
            if (feature1) {             
                hexPatches.ウォールハック検知回避.Modify();              
            } else {
                hexPatches.ウォールハック検知回避.Restore();              
            }
            break;
		case 23:
			feature1 = boolean;
            if (feature1) {             
                hexPatches.広告削除.Modify();              
            } else {
                hexPatches.広告削除.Restore();              
            }
            break;
		case 24 :
			feature1 = boolean;
            if (feature1) {             
                hexPatches.巨大化.Modify();              
            } else {
                hexPatches.巨大化.Restore();              
            }
            break;
		case 26:
			feature1 = boolean;
            if (feature1) {             
                hexPatches.スポーン地点.Modify();              
            } else {
                hexPatches.スポーン地点.Restore();              
            }
            break;
		case 27:
			feature1 = boolean;
            if (feature1) {             
                hexPatches.オブジェクト削除.Modify();              
            } else {
                hexPatches.オブジェクト削除.Restore();              
            }
            break;
		case 28:
			StampAuto = boolean;
			break;
		case 29:
		    ChatSpam = boolean;
			break;
		case 30:
			gameready = boolean;
			break;	
	    case 31:
			feature1 = boolean;
            if (feature1) {             
                hexPatches.壁貫通.Modify();              
            } else {
                hexPatches.壁貫通.Restore();              
            }
            break; 
		case 32:
			feature1 = boolean;
            if (feature1) {             
                hexPatches.コロバグ1.Modify();              
            } else {
                hexPatches.コロバグ1.Restore();              
            }
            break;
		case 33:
			feature1 = boolean;
            if (feature1) {             
                hexPatches.隠れ爆弾.Modify();              
            } else {
                hexPatches.隠れ爆弾.Restore();              
            }
            break;
		case 34:
			feature1 = boolean;
            if (feature1) {             
                hexPatches.スピード.Modify();              
            } else {
                hexPatches.スピード.Restore();              
            }
            break;
		case 35:
			AutoGamev1 = boolean;
			break;
		case 36:
			AutoBombv1 = boolean;
			break;	
		case 37:
			AutoGamev10 = true;		
			break;
		case 38:
			AutoBombv10 = true;				
			break;
		case 39:
			AutoJoinv1 = boolean;
			break;
		case 40:
			AutoJoinv10 = true;
			break;	
		case 41:
			AutoGamev20 = true;
			break;
		case 42:
		    AutoHidervalue = value;
			break;
		case 44:
			AutoBombv20 = boolean;		
			break;
		case 45:
			AutoBombvalue = value;
			break;
		case 46:
			Stamptype = value + 1;
			break;
		case 47:
			feature1 = boolean;
            if (feature1) {             
                hexPatches.死体操作.Modify();              
            } else {
                hexPatches.死体操作.Restore();              
            }
            break;
		case 48:
			test1 = boolean;
			break;
		case 49:
			test2 = boolean;
			break;
		case 50:
            if (value >= 1) {
            isLocalPlayerSize = value;
            }
            break;
    }
}
}

//No need to use JNI_OnLoad, since we don't use JNIEnv
//We do this to hide OnLoad from disassembler
__attribute__((constructor))
void lib_main() {
    // Create a new thread so it does not block the main thread, means the game would not freeze
    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}

/*
JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM *vm, void *reserved) {
    JNIEnv *globalEnv;
    vm->GetEnv((void **) &globalEnv, JNI_VERSION_1_6);
    return JNI_VERSION_1_6;
}
 */
