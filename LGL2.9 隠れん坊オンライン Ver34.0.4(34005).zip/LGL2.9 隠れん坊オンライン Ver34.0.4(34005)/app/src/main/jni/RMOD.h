#ifndef ANDROID_MOD_MENU_RMOD_H
#define ANDROID_MOD_MENU_RMOD_H
namespace RMOD {
    enum RMOD {

テスト1 = 0xA4FF20,
};
}
    
#endif


